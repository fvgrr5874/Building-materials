package sqltools;

public class xiaoshou {
	private String id;
	private String xinxi_id;
	private String shouru_id;	
	private String xinxi_name;	
	private String xinxi_jiage;	
	private String xiaoshoushuliang;
	private String time;
	public String getShouru_id() {
		return shouru_id;
	}
	public void setShouru_id(String shouru_id) {
		this.shouru_id = shouru_id;
	}

	
	public String getXinxi_jiage() {
		return xinxi_jiage;
	}
	public void setXinxi_jiage(String xinxi_jiage) {
		this.xinxi_jiage = xinxi_jiage;
	}

	public String getXinxi_name() {
		return xinxi_name;
	}
	public void setXinxi_name(String xinxi_name) {
		this.xinxi_name = xinxi_name;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getXinxi_id() {
		return xinxi_id;
	}
	public void setXinxi_id(String xinxi_id) {
		this.xinxi_id = xinxi_id;
	}
	public String getXiaoshoushuliang() {
		return xiaoshoushuliang;
	}
	public void setXiaoshoushuliang(String xiaoshoushuliang) {
		this.xiaoshoushuliang = xiaoshoushuliang;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}
