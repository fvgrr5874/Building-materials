package sqltools;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import jiancai.lianjie;

public class shourutools {

	public List<shouru> shouruData() {
		String sql = "select id,xinxi_id,xinxi_name,shouru,xinxi_jiage,time from shouru";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<shouru> ls = new ArrayList<shouru>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat();
				shouru xi = new shouru();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_id"));
				xi.setXinxi_jiage(rs.getString("xinxi_jiage"));
				xi.setXinxi_name(rs.getString("xinxi_name"));
				xi.setShouru(rs.getString("shouru"));
				xi.setTime(rs.getString("time"));
					ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public int Addshouru(shouru xs) {
		int i = 0;
		String sql = "insert into shouru (id,xinxi_id,xinxi_name,xinxi_jiage,xiaoshoushuliang,shouru,time) values(?,?,?,?,?,?,?)";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			
			st.setString(1, xs.getId());
			st.setString(2, xs.getXinxi_id());
			st.setString(3, xs.getXinxi_name());
			st.setString(4, xs.getXinxi_jiage());
			st.setString(5, xs.getXiaoshoushuliang());
			int jiage = (Integer.valueOf(xs.getXinxi_jiage())) * (Integer.valueOf(xs.getXiaoshoushuliang()));
			st.setString(6,Integer.toString(jiage));
			st.setString(7, xs.getTime());		
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public List<shouru> serch_shouru_time(String time1,String time2) {
		String sql = "select id,xinxi_id,xinxi_name,xiaoshoushuliang,shouru,xinxi_jiage,time from shouru where time >='" + time1 + "' and time <= '" + time2 + "'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		
		List<shouru> ls=new ArrayList<shouru>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat();
				shouru xi = new shouru();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_id"));
				xi.setXinxi_jiage(rs.getString("xinxi_jiage"));
				xi.setXinxi_name(rs.getString("xinxi_name"));
				xi.setXiaoshoushuliang(rs.getString("xiaoshoushuliang"));
				xi.setShouru(rs.getString("shouru"));
				xi.setTime(rs.getString("time"));
					ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
}
