package sqltools;

import java.util.Iterator;

public class jiancai {
	private String id;
	private String name;
	private String gongyingshang;
	private String cangku;
	public String getId() {
		return id;
	}
	public void setId(String string) {
		this.id = string;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGongyingshang() {
		return gongyingshang;
	}
	public void setGongyingshang(String gongyingshang) {
		this.gongyingshang = gongyingshang;
	}
	public String getCangku() {
		return cangku;
	}
	public void setCangku(String cangku) {
		this.cangku = cangku;
	}
	public static Iterator<jiancai> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
