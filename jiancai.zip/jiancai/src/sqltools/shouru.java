package sqltools;

public class shouru {
	private String id;
	private String xinxi_id;
	private String xinxi_name;
	private String xinxi_jiage;
	private String xiaoshoushuliang;
	public String getXiaoshoushuliang() {
		return xiaoshoushuliang;
	}
	public void setXiaoshoushuliang(String xiaoshoushuliang) {
		this.xiaoshoushuliang = xiaoshoushuliang;
	}
	private String shouru;
	private String time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getXinxi_id() {
		return xinxi_id;
	}
	public void setXinxi_id(String xinxi_id) {
		this.xinxi_id = xinxi_id;
	}
	public String getXinxi_name() {
		return xinxi_name;
	}
	public void setXinxi_name(String xinxi_name) {
		this.xinxi_name = xinxi_name;
	}
	public String getXinxi_jiage() {
		return xinxi_jiage;
	}
	public void setXinxi_jiage(String xinxi_jiage) {
		this.xinxi_jiage = xinxi_jiage;
	}

	public String getShouru() {
		return shouru;
	}
	public void setShouru(String shouru) {
		this.shouru = shouru;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}
