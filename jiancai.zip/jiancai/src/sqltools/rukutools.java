package sqltools;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import jiancai.lianjie;

public class rukutools {
	public List<ruku> rukuData() {
		String sql = "select id,xinxi_id,xinxi_name,rukushuliang,time from ruku";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<ruku> ls = new ArrayList<ruku>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat();
				ruku xi = new ruku();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_id"));
				xi.setXinxi_name(rs.getString("xinxi_name"));
				xi.setRukushuliang(rs.getString("rukushuliang"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
	public int Addruku(ruku rk) {
		int i = 0;
		String sql = "insert into ruku (id,xinxi_id,xinxi_name,rukushuliang,time) values(?,?,?,?,?)";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, rk.getId());
			st.setString(2, rk.getXinxi_id());
			st.setString(3, rk.getXinxi_name());
			st.setString(4, rk.getRukushuliang());
			st.setString(5, rk.getTime());
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public List<ruku> serch_ruku_time(String time1,String time2) {
		String sql = "select id,xinxi_id,xinxi_name,rukushuliang,time from ruku where time >= '" + time1 + "'and time <= '"+time2+"'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;		
		List<ruku> ls=new ArrayList<ruku>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				ruku xi = new ruku();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_name"));
				xi.setXinxi_name(rs.getString("xinxi_name"));
				xi.setRukushuliang(rs.getString("rukushuliang"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return ls;
	}
}
