package sqltools;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import jiancai.lianjie;

public class jiancaitools {
	public List<jiancai> jiancaiData(){
		String sql = "select id,name,gongyingshang,cangku from jiancai";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<jiancai> ls = new ArrayList<jiancai>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				jiancai jc = new jiancai();
				jc.setId(rs.getString("id"));
				jc.setName(rs.getString("name"));
				jc.setGongyingshang(rs.getString("gongyingshang"));
				jc.setCangku(rs.getString("cangku"));
				ls.add(jc);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public List<jiancai> jiancaiData(String name) {
		String sql = "select id,name,gongyingshang,cangku from jiancai where name like '%" + name + "%'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<jiancai> ls = new ArrayList<jiancai>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				jiancai jc = new jiancai();
				jc.setId(rs.getString("id"));
				jc.setName(rs.getString("name"));
				jc.setGongyingshang(rs.getString("gongyingshang"));
				jc.setCangku(rs.getString("cangku"));
				ls.add(jc);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public List<jiancai> serch_jiancai(String id) {
		String sql = "select id,name,gongyingshang,cangku from jiancai where id = '" + id + "'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		jiancai jc = null;
		List<jiancai> ls = new ArrayList<jiancai>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				jc = new jiancai();
				jc.setId(rs.getString("id"));
				jc.setName(rs.getString("name"));
				jc.setGongyingshang(rs.getString("gongyingshang"));
				jc.setCangku(rs.getString("cangku"));
				ls.add(jc);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public int Addjiancai(jiancai jc) {
		int i = 0;
		String sql = "insert into jiancai (id,name,gongyingshang,cangku) values(?,?,?,?)";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, jc.getId());
			st.setString(2, jc.getName());
			st.setString(3, jc.getGongyingshang());
			st.setString(4, jc.getCangku());
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int Updatejiancai(jiancai jc) {
		int i=0;
		String sql="update jiancai set id=?,name=?,gongyingshang=?,cangku=? where id=?";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, jc.getId());
			st.setString(2, jc.getName());
			st.setString(3, jc.getGongyingshang());
			st.setString(4, jc.getCangku());
			st.setString(5, jc.getId());
			i=st.executeUpdate();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}	
	public int Deletejiancai(String id) {
		int i=0;
		String sql="delete from jiancai where id=?";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, id);
			i=st.executeUpdate();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}
}
