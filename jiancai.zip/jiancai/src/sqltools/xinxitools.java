package sqltools;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.mysql.jdbc.Connection;

import jiancai.lianjie;

public class xinxitools {
	public List<xinxi> xinxiiData() {
		String sql = "select id,name,jiage,shouru,kucun,time from xinxi";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<xinxi> ls = new ArrayList<xinxi>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat();
				xinxi xi = new xinxi();
				xi.setId(rs.getString("id"));
				xi.setName(rs.getString("name"));
				xi.setJiage(rs.getString("jiage"));
				xi.setShouru(rs.getString("shouru"));
				xi.setKucun(rs.getString("kucun"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public List<xinxi> xinxiData(String name) {
		String sql = "select id,name,jiage,shouru,kucun,time from xinxi where name like '%" + name + "%'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		
		List<xinxi> ls=new ArrayList<xinxi>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				xinxi xi = new xinxi();
				xi.setId(rs.getString("id"));
				xi.setName(rs.getString("name"));
				xi.setJiage(rs.getString("jiage"));
				xi.setShouru(rs.getString("shouru"));
				xi.setKucun(rs.getString("kucun"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public List<xinxi> serch_xinxi(String id) {
		String sql = "select id,name,jiage,shouru,kucun,time from xinxi where id = '" + id + "'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		xinxi xi = new xinxi();
		List<xinxi> ls=new ArrayList<xinxi>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				xi.setId(rs.getString("id"));
				xi.setName(rs.getString("name"));
				xi.setJiage(rs.getString("jiage"));
				xi.setShouru(rs.getString("shouru"));
				xi.setKucun(rs.getString("kucun"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
	public List<xinxi> serch_xinxi_time(String time) {
		String sql = "select id,name,jiage,shouru,kucun,time from xinxi where time like '" + time + "' ";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<xinxi> ls=new ArrayList<xinxi>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				xinxi xi = new xinxi();
				xi.setId(rs.getString("id"));
				xi.setName(rs.getString("name"));
				xi.setJiage(rs.getString("jiage"));
				xi.setShouru(rs.getString("shouru"));
				xi.setKucun(rs.getString("kucun"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	public int Addjiancai(xinxi xi) {
		int i = 0;
		String sql = "insert into xinxi (id,name,jiage,kucun,time) values(?,?,?,?,?)";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, xi.getId());
			st.setString(2, xi.getName());
			st.setString(3, xi.getJiage());
			st.setString(4, xi.getKucun());
			st.setString(5, xi.getTime());
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public int Updatexinxi(xinxi xi) {
		int i=0;
		String sql="update xinxi set id=?,name=?,jiage=?,kucun=?,time=? where id=?";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, xi.getId());
			st.setString(2, xi.getName());
			st.setString(3, xi.getJiage());
			st.setString(4, xi.getKucun());
			st.setString(5, xi.getTime());
			st.setString(6, xi.getId());
			i = st.executeUpdate();
			st.close();
			conn.close();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}	
	public int Deletexinxi(String id) {
		int i=0;
		String sql="delete from xinxi where id=?";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, id);
			i=st.executeUpdate();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}
}
