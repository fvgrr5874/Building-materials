package sqltools;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import jiancai.lianjie;

public class xiaoshoutools {
	public List<xiaoshou> xiaoshouData() {
		String sql = "select id,xinxi_id,xinxi_name,xinxi_jiage,xiaoshoushuliang,time from xiaoshou";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		List<xiaoshou> ls = new ArrayList<xiaoshou>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SimpleDateFormat sdf = new SimpleDateFormat();
				xiaoshou xi = new xiaoshou();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_id"));
				xi.setXinxi_name(rs.getString("xinxi_name"));
				xi.setXinxi_jiage(rs.getString("xinxi_jiage"));
				xi.setXiaoshoushuliang(rs.getString("xiaoshoushuliang"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
	public int Addxiaoshou(xiaoshou xs) {
		int i = 0;
		String sql = "insert into xiaoshou (id,xinxi_id,xinxi_name,xinxi_jiage,xiaoshoushuliang,time) values(?,?,?,?,?,?)";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, xs.getId());
			st.setString(2, xs.getXinxi_id());
			st.setString(3, xs.getXinxi_name());
			st.setString(4, xs.getXinxi_jiage());
			st.setString(5, xs.getXiaoshoushuliang());
			st.setString(6, xs.getTime());
			
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	public List<xiaoshou> serch_xiaoshou_time(String time1,String time2) {
		String sql = "select id,xinxi_id,xinxi_name,xinxi_jiage,xiaoshoushuliang,time from xiaoshou where time >='" + time1 + "' and time <= '" + time2 + "'";
		lianjie lj = new lianjie();
		Connection conn = lj.getConn();
		ResultSet rs = null;
		
		List<xiaoshou> ls=new ArrayList<xiaoshou>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				xiaoshou xi = new xiaoshou();
				xi.setId(rs.getString("id"));
				xi.setXinxi_id(rs.getString("xinxi_id"));
				xi.setXinxi_id(rs.getString("xinxi_name"));
				xi.setXinxi_jiage(rs.getString("xinxi_jiage"));
				xi.setXiaoshoushuliang(rs.getString("xiaoshoushuliang"));
				xi.setTime(rs.getString("time"));
				ls.add(xi);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
}
