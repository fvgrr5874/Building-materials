package sqltools;

public class ruku {
	private String id;
	private String xinxi_id;
	private String xinxi_name;
	public String getXinxi_name() {
		return xinxi_name;
	}
	public void setXinxi_name(String xinxi_name) {
		this.xinxi_name = xinxi_name;
	}
	private String rukushuliang;
	private String time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getXinxi_id() {
		return xinxi_id;
	}
	public void setXinxi_id(String xinxi_id) {
		this.xinxi_id = xinxi_id;
	}
	public String getRukushuliang() {
		return rukushuliang;
	}
	public void setRukushuliang(String rukushuliang) {
		this.rukushuliang = rukushuliang;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}
