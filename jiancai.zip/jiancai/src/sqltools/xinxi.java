package sqltools;


public class xinxi {
	private String id;
	private String name;
	private String jiage;
	private String kucun;
	private String time;
	private String shouru;
	//private String shouru_id;
	public String getShouru() {
		return shouru;
	}
	public void setShouru(String shouru) {
		this.shouru = shouru;
	}
	public void setId(String id) {
		this.id = id;
	}	
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJiage() {
		return jiage;
	}
	public void setJiage(String jiage) {
		this.jiage = jiage;
	}
	public String getKucun() {
		return kucun;
	}
	public void setKucun(String kucun) {
		this.kucun = kucun;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}


}
