package jiancai;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import sqltools.Admin;

public class Login {
	Admin admin;

	void setAdmin(Admin admin) {
		this.admin = admin;
	}

	private String driver = "com.mysql.jdbc.Driver";
	private String url = "jdbc:mysql://127.0.0.1:3306/f?useUnicode = true&characterEncoding=UTF-8";
	private String user = "root";
	private String password = "123456";
	
	public boolean login(Admin admin) throws SQLException,ClassNotFoundException{
		String sql = "select * from admin where id =? and password=?";
		Class.forName(driver);
		Connection conn = (Connection) DriverManager.getConnection(url,user,password);
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(sql);
		
		ps.setString(1, admin.getId());
		ps.setString(2, admin.getPassword());
		ResultSet rs = ps.executeQuery();
		int ans = 0;
		if(rs.next()) {
			ans = 1;
		}
		rs.close();
		ps.close();
		conn.close();
		if(ans == 1) {
			return true;
		}else {
			return false;
		}

	}
	int JudgeAdmin() {
			try {
				if(login(this.admin)) {
					System.out.println("登陆成功");
					return 1;
				}else {
					return 0;
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		return 0;
		}
}
