package jiancai;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;

public class ShowDataTables extends JFrame {
	private JScrollPane scp;
	JTextField jTextField;
	private JTableHeader jth;
	private JTable tabDemo;
	private JButton bt, btnShow, btnShowData, btnShowData2, btnShowData3, btnShowData4, btnShowData5,sr;
	private JPanel contentPane;
	private JLabel bg, title;
	private JRadioButton id, name, day;
	private ButtonGroup group;
	private DefaultTableModel defaultModel;

	public ShowDataTables() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);

		title = new JLabel("建材管理系统");
		title.setFont(new Font("宋体", Font.BOLD, 40));
		title.setBounds(25, 0, 300, 100);
		contentPane.add(title);
		
		btnShowData2 = new JButton("入库");
		btnShowData2.setBounds(60, 100, 90, 30);
		contentPane.add(btnShowData2);
		btnShowData2.addActionListener(new ActionListener() // 给“商品信息”按钮添加事件响应。
		{
			public void actionPerformed(ActionEvent ae) {
				setVisible(false);
				rukuFrame rk = new rukuFrame();
			}
		});	

		btnShowData3 = new JButton("出库");		
		btnShowData3.setBounds(60, 165, 90, 30);
		contentPane.add(btnShowData3);
		btnShowData3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				xiaoshouFrame rk = new xiaoshouFrame();
			}
			
		});
		
		btnShowData4 = new JButton("详细信息");		
		btnShowData4.setBounds(60, 235, 90, 30);
		contentPane.add(btnShowData4);
		btnShowData4.addActionListener(new ActionListener() // 给“商品信息”按钮添加事件响应。
		{
			public void actionPerformed(ActionEvent ae) {
				try {
					setVisible(false);
					xinxiFrame xi = new xinxiFrame();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});	
		
		btnShowData5 = new JButton("退出");
		btnShowData5.setBounds(660, 5, 90, 30);
		contentPane.add(btnShowData5);
		btnShowData5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				denglu1 text = new denglu1();
			}

		});	

		sr = new JButton("收入情况");
		sr.setBounds(660, 300, 90, 30);
		contentPane.add(sr);
		sr.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				try {
					shouruFrame text = new shouruFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});	
		
		bt = new JButton("基本信息");
		bt.setBounds(60, 300, 90, 30);
		contentPane.add(bt);
		bt.addActionListener(new ActionListener() // 给“基本信息”按钮添加事件响应。
		{
			public void actionPerformed(ActionEvent ae) {
					try {
						setVisible(false);
						jincaiFrame  ji = new jincaiFrame();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		});		
	

		


		ImageIcon icon = new ImageIcon("./imgs/beijing2.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);

	


		/******* 将组件加入到窗体中 ******/
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("管理系统");
		this.setBounds(500, 400, 800, 400); // 控制窗体大小
	}
	public void btnShowData_ActionPerformed(ActionEvent ae) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://127.0.0.1:3306/f?useUnicode = true&characterEncoding=UTF-8";// 注意设置时区
			String username = "root";
			String passwords = "123456";
			Connection conn = DriverManager.getConnection(url, username, passwords);
			String sql = "select * from xinxi";
			PreparedStatement pstm = conn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			int count = 0;
			while (rs.next()) {
				count++;
			}
			rs = pstm.executeQuery();
			// 将查询获得的记录数据，转换成适合生成JTable的数据形式
			Object[][] info = new Object[count][7];
			String[] title = { "序号", "商品名称", "价格(元/kg)", "库存", "更新时间"};
			count = 0;
			while (rs.next()) {
				info[count][0] = Integer.valueOf(rs.getInt("id"));
				info[count][1] = rs.getString("name");
				info[count][2] = rs.getString("jiage");
				info[count][3] = rs.getString("kucun");
				info[count][4] = rs.getString("time");
				count++;
			}
			// 创建JTable
			this.tabDemo = new JTable(info, title);
			tabDemo.setOpaque(false);
			// 显示表头
			this.jth = this.tabDemo.getTableHeader();
			// 将JTable加入到带滚动条的面板中
			jth.setOpaque(false);
			this.scp.getViewport().add(tabDemo);
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
			JOptionPane.showMessageDialog(null, "数据源错误", "错误", JOptionPane.ERROR_MESSAGE);
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			JOptionPane.showMessageDialog(null, "数据操作错误", "错误", JOptionPane.ERROR_MESSAGE);
		}
	}
	public static void main(String[] args) {
		new ShowDataTables();
	}

}
