package jiancai;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import sqltools.jiancai;
import sqltools.jiancaitools;
import sqltools.ruku;
import sqltools.rukutools;
import sqltools.xiaoshou;
import sqltools.xiaoshoutools;
import sqltools.xinxi;
import sqltools.xinxitools;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class jiancaiRefister extends JFrame {
	JTextField jTextField,idt,namet,jgt,kct,xst,rst,gyst,ckt,sjt;
	private JButton bt,btnShow,btnShowData,btnShowData3,btnShowData4,btnShowData5,xin;
	private JPanel contentPane;
	private JLabel bg,title,id,name,gys,ck,jg,kc,xs,rs,sj;
	private ButtonGroup group;
	public jiancaiRefister() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));//距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		title = new JLabel("建材管理系统");
		title.setFont(new Font("宋体",Font.BOLD,30));
		title.setBounds(0, -30, 200, 100);
		btnShow = new JButton("增加信息");
		btnShow.setBounds(50, 60, 90, 20);	
		contentPane.add(btnShow);	
		btnShow.addActionListener(new ActionListener() // 给“增加数据”按钮添加事件响应。
		{
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				jiancaiRefister jR = new jiancaiRefister();
				
			}
		});	
		
		/*btnShowData = new JButton("删除信息");	
		btnShowData.setBounds(50, 120, 90, 20);
		contentPane.add(btnShowData);		
		btnShowData3 = new JButton("修改信息");
		btnShowData3.setBounds(50, 180, 90, 20);		
		contentPane.add(btnShowData3);	*/
		
		btnShowData4 = new JButton("详细信息");		
		btnShowData4.setBounds(50, 170, 90, 20);
		contentPane.add(btnShowData4);		
		btnShowData4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				ShowDataTables sh = new ShowDataTables();
				sh.btnShowData_ActionPerformed(e);
			}
			
		});		
		btnShowData5 = new JButton("退出");
		btnShowData5.setBounds(660, 5, 90, 20);		
		contentPane.add(btnShowData5);	
		btnShowData5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				denglu1 text = new denglu1();
			}
			
		});		
		bt = new JButton("基本信息");		
		bt.setBounds(50, 300, 90, 20);
		contentPane.add(bt);
		bt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				try {
					jincaiFrame jc = new jincaiFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		jTextField = new JTextField();
		contentPane.add(title);

		id = new JLabel("商品编号");
		id.setFont(new Font("宋体", Font.PLAIN, 20));
		id.setBounds(300, 25, 90, 20);
		idt = new JTextField();
		idt.setFont(new Font("宋体", Font.PLAIN, 20));
		idt.setBounds(400, 25, 100, 25);
		contentPane.add(id);
		contentPane.add(idt);
		
		name = new JLabel("商品名称");
		name.setFont(new Font("宋体", Font.PLAIN, 20));
		name.setBounds(300, 75, 90, 20);
		namet = new JTextField();
		namet.setFont(new Font("宋体", Font.PLAIN, 20));
		namet.setBounds(400, 75, 100, 25);
		contentPane.add(name);
		contentPane.add(namet);	
		
		jg = new JLabel("商品价格");
		jg.setFont(new Font("宋体", Font.PLAIN, 20));
		jg.setBounds(225, 125, 90, 20);
		jgt = new JTextField();
		jgt.setFont(new Font("宋体", Font.PLAIN, 20));
		jgt.setBounds(325, 125, 100, 25);
		contentPane.add(jg);
		contentPane.add(jgt);

		kc = new JLabel("商品库存");
		kc.setFont(new Font("宋体", Font.PLAIN, 20));
		kc.setBounds(475, 125, 90, 20);
		kct = new JTextField();
		kct.setFont(new Font("宋体", Font.PLAIN, 20));
		kct.setBounds(575, 125, 100, 25);
		contentPane.add(kc);
		contentPane.add(kct);
		
		xs = new JLabel("销售数量");
		xs.setFont(new Font("宋体", Font.PLAIN, 20));
		xs.setBounds(225, 175, 90, 20);
		xst = new JTextField();
		xst.setFont(new Font("宋体", Font.PLAIN, 20));
		xst.setBounds(325, 175, 100, 25);
		contentPane.add(xs);
		contentPane.add(xst);
		
		rs = new JLabel("入库数量");
		rs.setFont(new Font("宋体", Font.PLAIN, 20));
		rs.setBounds(475, 175, 90, 20);
		rst = new JTextField();
		rst.setFont(new Font("宋体", Font.PLAIN, 20));
		rst.setBounds(575, 175, 100, 25);
		contentPane.add(rs);
		contentPane.add(rst);	
		
		gys = new JLabel("供应商");
		gys.setFont(new Font("宋体", Font.PLAIN, 20));
		gys.setBounds(245, 225, 90, 25);
		gyst = new JTextField();
		gyst.setFont(new Font("宋体", Font.PLAIN, 20));
		gyst.setBounds(325, 225, 100, 25);
		contentPane.add(gys);
		contentPane.add(gyst);		

		ck = new JLabel("存储仓库");
		ck.setFont(new Font("宋体", Font.PLAIN, 20));
		ck.setBounds(475, 225, 90, 20);
		ckt = new JTextField();
		ckt.setFont(new Font("宋体", Font.PLAIN, 20));
		ckt.setBounds(575, 225, 100, 25);
		contentPane.add(ck);
		contentPane.add(ckt);
		
		sj = new JLabel("更新时间");
		sj.setFont(new Font("宋体", Font.PLAIN, 20));
		sj.setBounds(300, 270, 100, 20);
		sjt = new JTextField();
		sjt.setFont(new Font("宋体", Font.PLAIN, 20));
		sjt.setBounds(400, 270, 100, 25);
		contentPane.add(sj);
		contentPane.add(sjt);
		
		xin = new JButton("新增");
		xin.setBounds(400, 320, 90, 20);
		contentPane.add(xin);
		xin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				do_insertButton_Addjiancai();
				
			}
			
		});
	
		ImageIcon icon = new ImageIcon("./imgs/beijing2.png");
		bg = new JLabel(icon);
		bg.setBounds(0,0,icon.getIconWidth(),icon.getIconHeight());
		contentPane.add(bg);	
		
		


		/******* 将组件加入到窗体中 ******/
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("管理系统");
		this.setBounds(500,400,800,400); // 控制窗体大小
	}

	
	/*** 连接数据库并显示到表格中 ***/
	protected void do_insertButton_Addjiancai() {
		jiancaitools jiancait = new jiancaitools();
		jiancai jc = new jiancai();
		
		xinxitools xit = new xinxitools();
		xinxi xi = new xinxi();
		
		xiaoshoutools xsot = new xiaoshoutools();
		xiaoshou xso = new xiaoshou();
	
		rukutools rkt = new rukutools();
		ruku rk = new ruku();
	
		if(idt.getText() != null && !"".equals(idt.getText())
				&& namet.getText() != null && !"".equals(namet.getText())
				&& gyst.getText() != null && !"".equals(gyst.getText())
				&&ckt.getText() != null && !"".equals(ckt.getText())
				&&jgt.getText() != null && !"".equals(jgt.getText())
				&&kct.getText() != null && !"".equals(kct.getText())
				&&sjt.getText() != null && !"".equals(rst.getText())
				&&xst.getText() != null && !"".equals(xst.getText())
				&&rst.getText() != null && !"".equals(rst.getText())) {
			jc.setId(idt.getText());
			jc.setName(namet.getText());
			jc.setGongyingshang(gyst.getText());
			jc.setCangku(ckt.getText());
			
			xi.setJiage(jgt.getText());
			xi.setId(idt.getText());
			xi.setName(namet.getText());
			xi.setKucun(kct.getText());
			xi.setTime(sjt.getText());
			
			xso.setId(" ");
			xso.setXinxi_id(idt.getText());
			xso.setXinxi_name(namet.getText());
			xso.setXiaoshoushuliang(xst.getText());
			xso.setTime(sjt.getText());
			
			rk.setId(" ");
			rk.setXinxi_id(idt.getText());
			rk.setXinxi_name(namet.getText());
			rk.setRukushuliang(rst.getText());
			rk.setTime(sjt.getText());
			
			int i = jiancait.Addjiancai(jc);
			int j = xit.Addjiancai(xi);
			int k = xsot.Addxiaoshou(xso);
			int l = rkt.Addruku(rk);
			if((i == 1) && (j == 1) && (k == 1) && (l == 1)) {
				JOptionPane.showMessageDialog(getContentPane(), "成功新增建材信息！", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}else {
				JOptionPane.showMessageDialog(getContentPane(), "新增建材信息失败！", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}
		}else {
				JOptionPane.showMessageDialog(getContentPane(), "请输入完整资料", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}
	}


	public static void main(String[] args) {
		new jiancaiRefister();
	}

}
