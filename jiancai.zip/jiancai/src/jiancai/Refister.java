package jiancai;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class Refister {
	
	String name;
	String ID;
	String password;
	String confirmpassword;
	
	private String driver = "com.mysql.jdbc.Driver";
	private String user = "root";
	private String sqlpassword = "123456";
	private String url = "jdbc:mysql://127.0.0.1:3306/f?useUnicode = true&characterEncoding=UTF-8";
	
	void setName(String name) {
		this.name = name;
	}
	void setID(String ID) {
		this.ID = ID;
	}
	void setPassword(String password) {
		this.password = password;
	}
	void setconfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	boolean JudgeRehister() throws SQLException,ClassNotFoundException{
		if(this.name.equals("")) {
			JOptionPane.showMessageDialog(null, "用户名不能为空！","用户名",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if(this.ID.equals("")) {
			JOptionPane.showMessageDialog(null, "账号不能为空！","账号为空",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if(this.password.equals("")) {
			JOptionPane.showMessageDialog(null, "密码不能为空！","密码为空",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		addAdmin();
		return true;
	}
	void addAdmin() throws ClassNotFoundException,SQLException{
		String sql = "insert into admin (id,name,password) values (?,?,?)";
		Class.forName(driver);
		try {
			Connection conn = (Connection) DriverManager.getConnection(url,user,sqlpassword);
			PreparedStatement ps = (PreparedStatement) conn.prepareStatement(sql);
			ps.setString(1, this.ID);
			ps.setString(2, this.name);
			ps.setString(3, this.password);
			ps.executeUpdate();
			conn.close();
			JOptionPane.showMessageDialog(null, "注册成功");
			
		}catch(SQLException ex) {
			System.out.println("添加用户失败");
			JOptionPane.showMessageDialog(null, "添加用户失败","添加用户失败",JOptionPane.NO_OPTION);
		}	
	}
}
