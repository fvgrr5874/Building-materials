package jiancai;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import sqltools.jiancai;
import sqltools.jiancaitools;
import sqltools.ruku;
import sqltools.rukutools;
import sqltools.xiaoshou;
import sqltools.xiaoshoutools;
import sqltools.xinxi;
import sqltools.xinxitools;

public class rukuFrame extends JFrame{
	private JTable tabDemo;
	private DefaultTableModel defaultModel;
	private JPanel contentPane;
	private JButton jb,so,jb1,jb2,jb3,bt3,btnShowData5;
	private JScrollPane scp;
	private JTextField jTextField1,jTextField2;
	private JLabel title,bg;
	public rukuFrame() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		title = new JLabel("建材管理系统");
		title.setFont(new Font("宋体", Font.BOLD, 30));
		title.setBounds(0, -30, 200, 100);
		contentPane.add(title);
		
		jb = new JButton("商品入库");
		jb.setBounds(60, 100, 90, 30);
		contentPane.add(jb);
		jb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				ruku_RegisterFrame book_RegisterFrame = new ruku_RegisterFrame();
			}
			
		});
		
		jTextField1 = new JTextField();	
		jTextField2 = new JTextField();
		contentPane.add(title);
		jTextField1.setFont(new Font("宋体", Font.PLAIN, 15));
		jTextField1.setBounds(320, 20, 90, 30);
		contentPane.add(jTextField1);
		jTextField2.setFont(new Font("宋体", Font.PLAIN, 15));
		jTextField2.setBounds(420, 20, 90, 30);
		contentPane.add(jTextField2);		
		so = new JButton("搜索");
		so.setBounds(550, 20, 70, 30);
		contentPane.add(so);
		so.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				search_ruku();
			}
			
		});	
		
		jb1 = new JButton("商品出库");
		jb1.setBounds(60, 165, 90, 30);
		contentPane.add(jb1);
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				xiaoshou_RegisterFrame book_RegisterFrame = new xiaoshou_RegisterFrame();
			}
			
		});
		
		jb2 = new JButton("详细信息");
		jb2.setBounds(60, 235, 90, 30);
		contentPane.add(jb2);
		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					setVisible(false);
					xinxiFrame xi = new xinxiFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		
		jb3 = new JButton("基本信息");
		jb3.setBounds(60, 300, 90, 30);
		contentPane.add(jb3);
		jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					setVisible(false);
					jincaiFrame  ji = new jincaiFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		
		bt3 = new JButton("回到首页");
		bt3.setBounds(690, 330, 90, 20);
		contentPane.add(bt3);
		bt3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					setVisible(false);
					ShowDataTables show  = new ShowDataTables();

			}
			
		});
		
		btnShowData5 = new JButton("退出");
		btnShowData5.setBounds(660, 5, 90, 20);		
		contentPane.add(btnShowData5);
		btnShowData5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				denglu1 dl = new denglu1();
			}
			
		});
		scp = new JScrollPane();
		scp.setBounds(220, 80, 500, 230);
		contentPane.add(scp);
		show_data();
		
		ImageIcon icon = new ImageIcon("./imgs/beijing2.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);
	
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("管理系统");
		this.setBounds(500, 400, 800, 400); // 控制窗体大小
		
	}
	private void show_data() {
		tabDemo = new JTable();
		tabDemo.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		tabDemo.setRowHeight(30);

		defaultModel = (DefaultTableModel) tabDemo.getModel();
		defaultModel.setRowCount(0);
		defaultModel.setColumnIdentifiers(new Object[] { "序号", "建材编号", " 建材名字", "入库数量","入库时间" });

		tabDemo.getTableHeader().setReorderingAllowed(false);
		tabDemo.setModel(defaultModel);
		
		tabDemo.getColumnModel().getColumn(0).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(1).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(2).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(3).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(4).setPreferredWidth(75);
		
		rukutools readerTools = new rukutools();

		List<ruku> readerlist = readerTools.rukuData();	
		for (Iterator<ruku> iterator = readerlist.iterator(); iterator.hasNext();) {
				ruku temp = (ruku) iterator.next();
				defaultModel.addRow(new Object[] { temp.getId(), temp.getXinxi_id(), temp.getXinxi_name(),temp.getRukushuliang(),temp.getTime() });
			}
			scp.setViewportView(tabDemo);		
	}
	private void search_ruku() {
		tabDemo = new JTable();
		tabDemo.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		tabDemo.setRowHeight(20);

		defaultModel = (DefaultTableModel) tabDemo.getModel();
		defaultModel.setRowCount(0);
		defaultModel.setColumnIdentifiers(new Object[] { "序号", "建材编号", " 建材名字", "入库数量","入库时间" });

		tabDemo.getTableHeader().setReorderingAllowed(false);
		tabDemo.setModel(defaultModel);
		
		tabDemo.getColumnModel().getColumn(0).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(1).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(2).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(3).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(4).setPreferredWidth(75);
		
		rukutools readerTools = new rukutools();
		String keyword1 = null;
		String keyword2 = null;
		if (jTextField1.getText() != null && !"".equals(jTextField1.getText())
			&&jTextField2.getText() != null && !"".equals(jTextField2.getText())) {
			keyword1 = jTextField1.getText();
			keyword2 = jTextField2.getText();
			
		} else {
			show_data();
			JOptionPane.showMessageDialog(this, "请输入时间", "", JOptionPane.WARNING_MESSAGE);
			return;
		}

		List<ruku> readerlist = readerTools.serch_ruku_time(keyword1,keyword2);
		if (readerlist.size() == 0) {
			JOptionPane.showMessageDialog(this, "未找到有关建材 ", "", JOptionPane.WARNING_MESSAGE);
			return;
		} else {
			for (Iterator<ruku> iterator = readerlist.iterator(); iterator.hasNext();) {
				ruku temp = (ruku) iterator.next();
				defaultModel.addRow(new Object[] { temp.getId(), temp.getXinxi_id(), temp.getXinxi_name(),temp.getRukushuliang(),temp.getTime() });
			}
			scp.setViewportView(tabDemo);
		}
	}
	public static void main(String[] args) {
		rukuFrame rk = new rukuFrame();
	}
}
