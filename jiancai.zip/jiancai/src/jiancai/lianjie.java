package jiancai;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class lianjie {
	public Connection conn = null;

	public Connection getConn(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String username = "root";
			String password = "123456";
			String connectionUrl = "jdbc:mysql://127.0.0.1:3306/f?useUnicode = true&characterEncoding=UTF-8";
			conn = (Connection) DriverManager.getConnection(connectionUrl, username, password);
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
}
