package jiancai;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import sqltools.jiancai;
import sqltools.jiancaitools;
import sqltools.xinxi;
import sqltools.xinxitools;

public class xinxi_UpdateFrame extends JFrame{
	private static final long serialVersionUID = 1L;
	private JTextField namet,gongyingshangt,cangkut,timet;
	private JLabel id,name,gongyingshang,cangku,bg,ids,time;
	private JPanel contentPane;
	private JButton bt;
	public xinxi_UpdateFrame(xinxiFrame XinxiFrame) {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		id = new JLabel("商品编号");
		id.setFont(new Font("宋体", Font.PLAIN, 25));
		id.setBounds(50, 20, 137, 39);
		contentPane.add(id);

		ids = new JLabel();
		ids.setFont(new Font("宋体", Font.PLAIN, 25));
		ids.setForeground(Color.WHITE);
		ids.setBounds(170, 20, 137, 39);
		contentPane.add(ids);
		ids.setText(XinxiFrame.tabDemo.getValueAt(XinxiFrame.row, 0).toString());
		
		name = new JLabel("商品名称");
		name.setFont(new Font("宋体", Font.PLAIN, 25));
		name.setBounds(50, 90, 137, 39);		
		namet = new JTextField();
		namet.setFont(new Font("宋体", Font.PLAIN, 25));
		namet.setBounds(170, 90, 137, 39);
		contentPane.add(name);
		contentPane.add(namet);
		namet.setText(XinxiFrame.tabDemo.getValueAt(XinxiFrame.row, 1).toString());
		
		gongyingshang = new JLabel("商品价格");
		gongyingshang.setFont(new Font("宋体", Font.PLAIN, 25));
		gongyingshang.setBounds(50, 180, 137, 39);
		gongyingshangt = new JTextField();
		gongyingshangt.setFont(new Font("宋体", Font.PLAIN, 25));
		gongyingshangt.setBounds(170, 180, 137, 39);		
		contentPane.add(gongyingshang);
		contentPane.add(gongyingshangt);
		gongyingshangt.setText(XinxiFrame.tabDemo.getValueAt(XinxiFrame.row, 2).toString());
		
		cangku = new JLabel("商品库存");
		cangku.setFont(new Font("宋体", Font.PLAIN, 25));
		cangku.setBounds(50, 260, 137, 39);
		cangkut = new JTextField();
		cangkut.setFont(new Font("宋体", Font.PLAIN, 25));
		cangkut.setBounds(170, 260, 137, 39);
		contentPane.add(cangku);
		contentPane.add(cangkut);
		cangkut.setText(XinxiFrame.tabDemo.getValueAt(XinxiFrame.row, 3).toString());

		time = new JLabel("更新时间");
		time.setFont(new Font("宋体", Font.PLAIN, 25));
		time.setBounds(50, 350, 137, 39);
		timet = new JTextField();
		timet.setFont(new Font("宋体", Font.PLAIN, 25));
		timet.setBounds(170, 350, 137, 39);
		contentPane.add(time);
		contentPane.add(timet);
		timet.setText(XinxiFrame.tabDemo.getValueAt(XinxiFrame.row, 4).toString());
		
		bt = new JButton("更新");
		bt.setBounds(170, 420, 60, 30);
		contentPane.add(bt);
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_updateButton();
			}
		});
		
		ImageIcon icon = new ImageIcon("./imgs/beijing3.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);
	
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle("修改信息");
		this.setBounds(300, 300, 450, 500); // 控制窗体大小
	}
	protected void do_updateButton() {
		xinxitools jct = new xinxitools();
		xinxi jc = new xinxi();
		if ( ids.getText() != null && !"".equals(ids.getText()) 
				&& namet.getText() != null && !"".equals(namet.getText())
				&& gongyingshangt.getText() != null && !"".equals(gongyingshangt.getText())
				&& cangkut.getText() != null && !"".equals(cangkut.getText())
				&& timet.getText() != null && !"".equals(timet.getText())) {
			jc.setId(ids.getText());
			jc.setName(namet.getText());
			jc.setJiage(gongyingshangt.getText());
			jc.setKucun(cangkut.getText());
			jc.setTime(timet.getText());
			int i = jct.Updatexinxi(jc);
			if ( i == 1 ) {
	            JOptionPane.showMessageDialog(getContentPane(), "成功新增信息！", "", JOptionPane.WARNING_MESSAGE);
	            return;
			} else {
	            JOptionPane.showMessageDialog(getContentPane(), "新增信息失败！", "", JOptionPane.WARNING_MESSAGE);
	            return;
			}
		} else {
            JOptionPane.showMessageDialog(getContentPane(), "请输入完整信息", "", JOptionPane.WARNING_MESSAGE);
            return;
		}
	}
}
