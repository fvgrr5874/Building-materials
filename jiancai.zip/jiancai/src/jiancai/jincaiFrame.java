package jiancai;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import sqltools.jiancai;
import sqltools.jiancaitools;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

public class jincaiFrame extends JFrame {
	private JScrollPane scp;
	JTextField jTextField;
	private JTableHeader jth;
	public JTable tabDemo;
	private JButton bt,bt1,bt2,bt3, btnShow, btnShowData, btnShowData3, btnShowData4, btnShowData5, so, ge;
	private JPanel contentPane;
	private JLabel bg, title;
	private ButtonGroup group;
	private DefaultTableModel defaultModel;
	public int row;
	
	public jincaiFrame() throws ClassNotFoundException, SQLException {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);

		title = new JLabel("建材管理系统");
		title.setFont(new Font("宋体", Font.BOLD, 30));
		title.setBounds(0, -30, 200, 100);
		
		btnShow = new JButton("增加信息");
		btnShow.setBounds(50, 60, 90, 20);		
		contentPane.add(btnShow);
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				jiancaiRefister jR = new jiancaiRefister();
			}
		});
		btnShowData = new JButton("删除信息");		
		btnShowData.setBounds(50, 120, 90, 20);
		contentPane.add(btnShowData);
		btnShowData.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				delete_data();
			}
			
		});
		btnShowData3 = new JButton("修改信息");
		btnShowData3.setBounds(50, 180, 90, 20);		
		contentPane.add(btnShowData3);
		btnShowData3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				update_jiancai();
			}
			
		});
		
		btnShowData4 = new JButton("详细信息");
		btnShowData4.setBounds(50, 240, 90, 20);
		contentPane.add(btnShowData4);
		btnShowData4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					setVisible(false);
					xinxiFrame jc = new xinxiFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});		

		bt1 = new JButton("入库信息");
		bt1.setBounds(300, 330, 90, 20);
		contentPane.add(bt1);
		bt1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					setVisible(false);
					rukuFrame rk = new rukuFrame();

			}
			
		});
		
		bt2 = new JButton("出库信息");
		bt2.setBounds(500, 330, 90, 20);
		contentPane.add(bt2);
		bt2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					setVisible(false);
					xiaoshouFrame xiaoshou = new xiaoshouFrame();

			}
			
		});
		
		bt3 = new JButton("回到首页");
		bt3.setBounds(690, 330, 90, 20);
		contentPane.add(bt3);
		bt3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					setVisible(false);
					ShowDataTables show  = new ShowDataTables();

			}
			
		});
		
		btnShowData5 = new JButton("退出");
		btnShowData5.setBounds(660, 5, 90, 20);		
		contentPane.add(btnShowData5);
		btnShowData5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				denglu1 dl = new denglu1();
			}
			
		});
		bt = new JButton("基本信息");
		bt.setBounds(50, 300, 90, 20);
		contentPane.add(bt);
		bt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					setVisible(false);
					jincaiFrame jc = new jincaiFrame();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		jTextField = new JTextField();
		


		contentPane.add(title);


		jTextField = new JTextField();
		jTextField.setFont(new Font("宋体", Font.PLAIN, 15));
		jTextField.setBounds(320, 40, 200, 30);
		contentPane.add(jTextField);
		so = new JButton("搜索");
		so.setBounds(550, 40, 70, 30);
		contentPane.add(so);
		so.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				do_search_jaincai();
			}
			
		});



		scp = new JScrollPane();
		scp.setBounds(220, 80, 500, 230);
		contentPane.add(scp);
		show_data();
		
		ImageIcon icon = new ImageIcon("./imgs/beijing2.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);
	
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("管理系统");
		this.setBounds(500, 400, 800, 400); // 控制窗体大小

	}

	private void show_data() {
		tabDemo = new JTable();
		tabDemo.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		tabDemo.setRowHeight(30);

		defaultModel = (DefaultTableModel) tabDemo.getModel();
		defaultModel.setRowCount(0);
		defaultModel.setColumnIdentifiers(new Object[] { "序号", "商品名称", " 供应商", "仓库" });

		tabDemo.getTableHeader().setReorderingAllowed(false);
		tabDemo.setModel(defaultModel);
		
		tabDemo.getColumnModel().getColumn(0).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(1).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(2).setPreferredWidth(75);
		tabDemo.getColumnModel().getColumn(3).setPreferredWidth(75);
		
		jiancaitools readerTools = new jiancaitools();

		List<jiancai> readerlist = readerTools.jiancaiData();	
		for (Iterator<jiancai> iterator = readerlist.iterator(); iterator.hasNext();) {
				jiancai temp = (jiancai) iterator.next();
				defaultModel.addRow(new Object[] { temp.getId(), temp.getName(), temp.getGongyingshang(),temp.getCangku() });
			}
			scp.setViewportView(tabDemo);		
	}
	
	private void do_search_jaincai() {
		
		tabDemo = new JTable();
		tabDemo.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		tabDemo.setRowHeight(54);

		defaultModel = (DefaultTableModel) tabDemo.getModel();
		defaultModel.setRowCount(0);
		defaultModel.setColumnIdentifiers(new Object[] { "序号", "商品名称", " 供应商", "仓库" });

		tabDemo.getTableHeader().setReorderingAllowed(false);
		tabDemo.setModel(defaultModel);
		
		tabDemo.getColumnModel().getColumn(0).setPreferredWidth(20);
		tabDemo.getColumnModel().getColumn(1).setPreferredWidth(80);
		tabDemo.getColumnModel().getColumn(2).setPreferredWidth(30);
		tabDemo.getColumnModel().getColumn(3).setPreferredWidth(40);
		
		jiancaitools readerTools = new jiancaitools();
		String keyword = null;
		if (jTextField.getText() != null && !"".equals(jTextField.getText())) {
			keyword = jTextField.getText();
		} else {
			show_data();
			JOptionPane.showMessageDialog(this, "请输入建材名", "", JOptionPane.WARNING_MESSAGE);
			return;
		}

		List<jiancai> readerlist = readerTools.jiancaiData(keyword);

		if (readerlist.size() == 0) {
			JOptionPane.showMessageDialog(this, "未找到有关建材 ", "", JOptionPane.WARNING_MESSAGE);
			return;
		} else {
			for (Iterator<jiancai> iterator = readerlist.iterator(); iterator.hasNext();) {
				jiancai temp = (jiancai) iterator.next();
				defaultModel.addRow(new Object[] { temp.getId(), temp.getName(), temp.getGongyingshang(),temp.getCangku() });
			}
			scp.setViewportView(tabDemo);
		}
	}
	private void update_jiancai() {
		row = tabDemo.getSelectedRow();
		if (row == -1) {
			JOptionPane.showMessageDialog(this, "请选择建材！", "", JOptionPane.WARNING_MESSAGE);
			return;
		}
		jiancai_UpdateFrame jc = new jiancai_UpdateFrame(jincaiFrame.this);
	}
	private void delete_data() {
		int row = tabDemo.getSelectedRow();
		if (row == -1) {
			JOptionPane.showMessageDialog(this, "请选择建材", "", JOptionPane.WARNING_MESSAGE);
			return;
		}
		jiancaitools readerTools = new jiancaitools();
		int i = readerTools.Deletejiancai(tabDemo.getValueAt(row, 0).toString());
		if (i == 1) {
			JOptionPane.showMessageDialog(getContentPane(), "成功删除信息！", "", JOptionPane.WARNING_MESSAGE);
			this.show_data();
			return;
		} else {
			JOptionPane.showMessageDialog(getContentPane(), "删除读者信息失败！", "", JOptionPane.WARNING_MESSAGE);
			return;
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		jincaiFrame jc = new jincaiFrame();
	}

}
