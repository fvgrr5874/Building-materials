package jiancai;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import sqltools.jiancai;
import sqltools.jiancaitools;
import sqltools.ruku;
import sqltools.rukutools;
import sqltools.shouru;
import sqltools.shourutools;
import sqltools.xiaoshou;
import sqltools.xiaoshoutools;
import sqltools.xinxi;
import sqltools.xinxitools;

public class xiaoshou_RegisterFrame extends JFrame {
	private JTable tabDemo;
	private DefaultTableModel defaultModel;
	private JPanel contentPane;
	private JButton jb,jb1,btnShowData5,zj;
	private JTextField jTextField,jTextField1,jTextField2,jTextField3,jTextField4,jTextField5;
	private JLabel title,bg,id,xinxi_id,xinxi_name,rukushuliang,time,rukushuliang2;
	public xiaoshou_RegisterFrame() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		title = new JLabel("建材管理系统");
		title.setFont(new Font("宋体", Font.BOLD, 30));
		title.setBounds(0, -30, 200, 100);
		contentPane.add(title);
		
		jb = new JButton("入库情况");
		jb.setBounds(60, 100, 90, 30);
		contentPane.add(jb);
		jb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//ruku_RegisterFrame book_RegisterFrame = new ruku_RegisterFrame();
				setVisible(false);
				rukuFrame rk = new rukuFrame();
			}
			
		});
		
		id = new JLabel("编号");
		id.setBounds(300, 15, 137, 39);
		id.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(id);
		jTextField = new JTextField();
		jTextField.setBounds(370, 15, 137, 39);
		jTextField.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField);
		
		xinxi_id = new JLabel("商品编号");
		xinxi_id.setBounds(250, 90, 137, 39);
		xinxi_id.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(xinxi_id);
		jTextField1 = new JTextField();
		jTextField1.setBounds(370, 90, 137, 39);
		jTextField1.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField1);

		rukushuliang = new JLabel("商品名字");
		rukushuliang.setBounds(160, 165, 137, 39);
		rukushuliang.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(rukushuliang);
		jTextField2 = new JTextField();
		jTextField2.setBounds(280, 165, 137, 39);
		jTextField2.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField2);

		rukushuliang2 = new JLabel("商品价格");
		rukushuliang2.setBounds(450, 165, 137, 39);
		rukushuliang2.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(rukushuliang2);
		jTextField5 = new JTextField();
		jTextField5.setBounds(570, 165, 137, 39);
		jTextField5.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField5);
		
		xinxi_name = new JLabel("出库数量");
		xinxi_name.setBounds(250, 240, 137, 39);
		xinxi_name.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(xinxi_name);
		jTextField3 = new JTextField();
		jTextField3.setBounds(370, 240, 137, 39);
		jTextField3.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField3);

		time = new JLabel("出库时间");
		time.setBounds(250, 315, 137, 39);
		time.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(time);
		jTextField4 = new JTextField();
		jTextField4.setBounds(370, 315, 137, 39);
		jTextField4.setFont(new Font("宋体", Font.PLAIN, 25));
		contentPane.add(jTextField4);
		
		
		jb1 = new JButton("出库情况");
		jb1.setBounds(60, 200, 90, 30);
		contentPane.add(jb1);
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				xiaoshouFrame rk = new xiaoshouFrame();
			}
			
		});
		
		btnShowData5 = new JButton("退出");
		btnShowData5.setBounds(660, 5, 90, 20);		
		contentPane.add(btnShowData5);
		btnShowData5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				denglu1 dl = new denglu1();
			}
			
		});
		
		zj = new JButton("增加");
		zj.setBounds(660, 325, 60, 30);
		contentPane.add(zj);
		zj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_addButton();
			}
		});
		
		
		ImageIcon icon = new ImageIcon("./imgs/beijing2.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);
	
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("商品入库");
		this.setBounds(500, 400, 800, 400); // 控制窗体大小
		
	}
	protected void do_addButton() {
		xiaoshoutools rkt = new xiaoshoutools();
		xiaoshou rk = new xiaoshou();
		
		shourutools srt=new shourutools();
		shouru sr = new shouru();
	
		xinxitools xit = new xinxitools();
		xinxi xi = new xinxi();
		
		if(jTextField.getText() != null && !"".equals(jTextField.getText())
				&& jTextField1.getText() != null && !"".equals(jTextField1.getText())
				&& jTextField2.getText() != null && !"".equals(jTextField2.getText())
				&&jTextField3.getText() != null && !"".equals(jTextField3.getText())
				&&jTextField4.getText() != null && !"".equals(jTextField4.getText())
				&&jTextField5.getText() != null && !"".equals(jTextField5.getText())) {
			
			rk.setId(jTextField.getText());
			rk.setXinxi_id(jTextField1.getText());

			rk.setXinxi_name(jTextField2.getText());
			rk.setXinxi_jiage(jTextField5.getText());
			rk.setXiaoshoushuliang(jTextField3.getText());
			rk.setTime(jTextField4.getText());
			
			sr.setId(jTextField.getText());
			sr.setXinxi_id(jTextField1.getText());
			sr.setXinxi_name(jTextField2.getText());
			sr.setXinxi_jiage(jTextField5.getText());
			sr.setXiaoshoushuliang(jTextField3.getText());
			sr.setShouru(null);
			sr.setTime(jTextField4.getText());
			
			int l = rkt.Addxiaoshou(rk);
			int k = srt.Addshouru(sr);
			if((l == 1) && (k == 1)) {
				JOptionPane.showMessageDialog(getContentPane(), "成功新增建材信息！", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}else {
				JOptionPane.showMessageDialog(getContentPane(), "新增建材信息失败！", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}
		}else {
				JOptionPane.showMessageDialog(getContentPane(), "请输入完整资料", "", JOptionPane.WARNING_MESSAGE);
				return;				
			}
	}
	public static void main(String[] args) {
		xiaoshou_RegisterFrame rk = new xiaoshou_RegisterFrame();
	}

}
