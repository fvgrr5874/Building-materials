package jiancai;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import sqltools.jiancai;
import sqltools.jiancaitools;

public class jiancai_UpdateFrame extends JFrame{
	private static final long serialVersionUID = 1L;
	private JTextField namet,gongyingshangt,cangkut;
	private JLabel id,name,gongyingshang,cangku,bg,ids;
	private JPanel contentPane;
	private JButton bt;
	public jiancai_UpdateFrame(jincaiFrame jincaiFrame) {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));// 距离边框的空白像素
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		id = new JLabel("商品编号");
		id.setFont(new Font("宋体", Font.PLAIN, 25));
		id.setBounds(50, 50, 137, 39);
		contentPane.add(id);

		ids = new JLabel();
		ids.setFont(new Font("宋体", Font.PLAIN, 25));
		ids.setForeground(Color.WHITE);
		ids.setBounds(170, 50, 137, 39);
		contentPane.add(ids);
		ids.setText(jincaiFrame.tabDemo.getValueAt(jincaiFrame.row, 0).toString());
		
		name = new JLabel("商品名称");
		name.setFont(new Font("宋体", Font.PLAIN, 25));
		name.setBounds(50, 150, 137, 39);		
		namet = new JTextField();
		namet.setFont(new Font("宋体", Font.PLAIN, 25));
		namet.setBounds(170, 150, 137, 39);
		contentPane.add(name);
		contentPane.add(namet);
		namet.setText(jincaiFrame.tabDemo.getValueAt(jincaiFrame.row, 1).toString());
		
		gongyingshang = new JLabel("供应商");
		gongyingshang.setFont(new Font("宋体", Font.PLAIN, 25));
		gongyingshang.setBounds(75, 250, 137, 39);
		gongyingshangt = new JTextField();
		gongyingshangt.setFont(new Font("宋体", Font.PLAIN, 25));
		gongyingshangt.setBounds(170, 250, 137, 39);		
		contentPane.add(gongyingshang);
		contentPane.add(gongyingshangt);
		gongyingshangt.setText(jincaiFrame.tabDemo.getValueAt(jincaiFrame.row, 2).toString());
		
		cangku = new JLabel("存储仓库");
		cangku.setFont(new Font("宋体", Font.PLAIN, 25));
		cangku.setBounds(50, 350, 137, 39);
		cangkut = new JTextField();
		cangkut.setFont(new Font("宋体", Font.PLAIN, 25));
		cangkut.setBounds(170, 350, 137, 39);
		contentPane.add(cangku);
		contentPane.add(cangkut);
		cangkut.setText(jincaiFrame.tabDemo.getValueAt(jincaiFrame.row, 3).toString());
		
		bt = new JButton("更新");
		bt.setBounds(170, 420, 60, 30);
		contentPane.add(bt);
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_updateButton();
			}
		});
		
		ImageIcon icon = new ImageIcon("./imgs/beijing3.png");
		bg = new JLabel(icon);
		bg.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
		contentPane.add(bg);
	
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle("修改信息");
		this.setBounds(300, 300, 450, 500); // 控制窗体大小
	}
	protected void do_updateButton() {
		jiancaitools jct = new jiancaitools();
		jiancai jc = new jiancai();
		if ( ids.getText() != null && !"".equals(ids.getText()) 
				&& namet.getText() != null && !"".equals(namet.getText())
				&& gongyingshangt.getText() != null && !"".equals(gongyingshangt.getText())
				&& cangkut.getText() != null && !"".equals(cangkut.getText())) {
			jc.setId(ids.getText());
			jc.setName(namet.getText());
			jc.setGongyingshang(gongyingshangt.getText());
			jc.setCangku(cangkut.getText());
			int i = jct.Updatejiancai(jc);
			if ( i == 1 ) {
	            JOptionPane.showMessageDialog(getContentPane(), "成功新增信息！", "", JOptionPane.WARNING_MESSAGE);
	            return;
			} else {
	            JOptionPane.showMessageDialog(getContentPane(), "新增信息失败！", "", JOptionPane.WARNING_MESSAGE);
	            return;
			}
		} else {
            JOptionPane.showMessageDialog(getContentPane(), "请输入完整信息", "", JOptionPane.WARNING_MESSAGE);
            return;
		}
	}
}
