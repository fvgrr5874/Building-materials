package jiancai;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdminRegister extends JFrame{
	AdminRegister(){
		init();
	}
	void init() {
		ImageIcon icon = new ImageIcon("./imgs/beijing.png");
		JLabel bg = new JLabel(icon);
		bg.setBounds(0,0,icon.getIconWidth(),icon.getIconHeight());
		this.getLayeredPane().add(bg,Integer.valueOf(Integer.MIN_VALUE));
		
		this.setLayout(new GridLayout(6,1));
		
		JPanel imPanel = (JPanel)getContentPane();
		imPanel.setOpaque(false);	
		
		JPanel title = new JPanel();
		title.setOpaque(false);
		
		JLabel zhuce = new JLabel("注册账号");
		zhuce.setFont(new Font("宋体",Font.BOLD,40));	
		zhuce.setOpaque(false);
		title.add(zhuce);
		imPanel.add(title,BorderLayout.CENTER);
						
		JPanel enterPanel1 = new JPanel();
		enterPanel1.setOpaque(false);
		JPanel enterPanel2 = new JPanel();
		enterPanel2.setOpaque(false);
		JPanel enterPanel3 = new JPanel();
		enterPanel3.setOpaque(false);
		JPanel enterPanel4 = new JPanel();
		enterPanel4.setOpaque(false);
		
		JLabel nameStr = new JLabel("用户名");
		JTextField userName = new JTextField(13);
		userName.setOpaque(false);
		userName.setEditable(true);
		enterPanel1.add(nameStr);
		enterPanel1.add(userName);
		imPanel.add(enterPanel1,BorderLayout.CENTER);		

		JLabel IDStr = new JLabel("账号");
		JTextField userID = new JTextField(13);
		userID.setOpaque(false);
		userID.setEditable(true);
		enterPanel2.add(IDStr);
		enterPanel2.add(userID);
		imPanel.add(enterPanel2,BorderLayout.CENTER);	
		
		JLabel passwordStr = new JLabel("密码");
		JPasswordField password = new JPasswordField(13);
		password.setOpaque(false);
		password.setEditable(true);
		enterPanel3.add(passwordStr);
		enterPanel3.add(password);
		imPanel.add(enterPanel3,BorderLayout.CENTER);		
		
		JLabel confrimStr = new JLabel("确认密码");
		JPasswordField confrimpassword= new JPasswordField(13);
		confrimpassword.setOpaque(false);
		confrimpassword.setEditable(true);	
		enterPanel4.add(confrimStr);
		enterPanel4.add(confrimpassword);
		imPanel.add(enterPanel4,BorderLayout.CENTER);		
		

		JPanel buttonPanel = new JPanel();
		buttonPanel.setOpaque(false);
		
		JButton buttonrerister = new JButton("注册");
		buttonrerister.setOpaque(false);
		buttonPanel.add(buttonrerister);
		imPanel.add(buttonPanel,BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		setSize(icon.getIconWidth(),icon.getIconHeight());
		setResizable(false);
		this.setTitle("注册");
		this.setBounds(500,400,800,400);
		
		buttonrerister.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = userName.getText();
				String ID = userID.getText();
				String passwd =  String.valueOf(password.getPassword());	
				String confrimpasswd =  String.valueOf(confrimpassword.getPassword());
				
				Refister refister = new Refister();
				refister.setID(ID);
				refister.setName(name);
				refister.setPassword(passwd);
				refister.setconfirmpassword(confrimpasswd);
				
				try {
					if(refister.JudgeRehister()) {
						setVisible(false);
						denglu1 text = new denglu1();
						
						
					}
				}catch(SQLException e1) {
					e1.printStackTrace();
				}catch(ClassNotFoundException e1) {
					e1.printStackTrace();
				}
			}
			
		});
	}

}
