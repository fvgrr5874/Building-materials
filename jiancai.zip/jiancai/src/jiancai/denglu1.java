package jiancai;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.JTableHeader;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import sqltools.Admin;

public class denglu1 extends JFrame{
	public denglu1(){
		init();
	}
	public void init() {
		JTextField jTextField;
		JPasswordField jPasswordField;
		JLabel jLabel1,Jlabel2,bg,welcone;
		JPanel buttonPanel,imPanel,enterPanel1,enterPanel2,title;
		JButton jb1,jb2,button;
		
		ImageIcon icon = new ImageIcon("./imgs/jiancai.png");
		bg = new JLabel(icon);
		bg.setBounds(0,0,icon.getIconWidth(),icon.getIconHeight());
		this.getLayeredPane().add(bg,Integer.valueOf(Integer.MIN_VALUE));
		this.setLayout(new GridLayout(4,1));
		
		imPanel = (JPanel)getContentPane();
		imPanel.setOpaque(false);
		
		title = new JPanel();
		title.setOpaque(false);
		
		welcone = new JLabel("建材管理系统");
		welcone.setFont(new Font("宋体",Font.BOLD,40));	
		welcone.setOpaque(false);
		title.add(welcone);
		imPanel.add(title,BorderLayout.CENTER);
		

		
		enterPanel1 = new JPanel();
		enterPanel1.setOpaque(false);
		
		enterPanel2 = new JPanel();
		enterPanel2.setOpaque(false);
		
		jTextField = new JTextField(13);
		jPasswordField = new JPasswordField(13);
		
		jLabel1 = new JLabel("账号");
		jTextField.setOpaque(false);
		jTextField.setEditable(true);
		enterPanel1.add(jLabel1);
		enterPanel1.add(jTextField);
		imPanel.add(enterPanel1,BorderLayout.CENTER);
		
		Jlabel2 = new JLabel("密码");
		jPasswordField.setOpaque(false);
		jPasswordField.setEditable(true);		
		enterPanel2.add(Jlabel2);
		enterPanel2.add(jPasswordField);
		imPanel.add(enterPanel2,BorderLayout.CENTER);
		
		buttonPanel = new JPanel();
		buttonPanel.setOpaque(false);
		
		jb1 = new JButton("确认");
		jb2 = new JButton("注册");		
		
		jb1.setOpaque(false);
		jb2.setOpaque(false);
		buttonPanel.add(jb1);
		buttonPanel.add(jb2);
		imPanel.add(buttonPanel,BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setTitle("登录");
		setSize(icon.getIconWidth(),icon.getIconHeight());
		setResizable(false);
		this.setBounds(500,400,800,400);
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String ID = jTextField.getText();
				String passwd = String.valueOf(jPasswordField.getPassword());
				
				Admin admin = new Admin();
				admin.setId(ID);
				admin.setPassword(passwd);
				
				Login login = new Login();
				login.setAdmin(admin);
				if(login.JudgeAdmin() == 0) {
					JOptionPane.showMessageDialog(null, "账号或密码错误","账号或密码错误",JOptionPane.WARNING_MESSAGE);
					jTextField.setText("");
					jPasswordField.setText("");
					System.out.println("登陆失败");
				}else {
					//JOptionPane.showMessageDialog(null, "登陆成功","登陆成功",JOptionPane.NO_OPTION);
					setVisible(false);
					ShowDataTables sd = new ShowDataTables();
					
				}
				
			}
			
		});	
		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				AdminRegister ar = new AdminRegister();
				
			}
			
		});
	}
	public void ShowData (ActionEvent e){
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String username = "root";
				String password = "123456";
				String url = "jdbc:mysql://127.0.0.1:3306/f?useUnicode = true&characterEncoding=UTF-8";
				Connection conn = (Connection) DriverManager.getConnection(url, username, password);
				String sql = "select * from jiancai";
				PreparedStatement pstm = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet rs = (ResultSet) pstm.executeQuery();
				int count = 0;
				while(rs.next()) {
					count++;
				}
				rs = pstm.executeQuery();
				Object[][] info = new Object[count][4];
				String[] title = {"序号","名称","供应商","仓库"};
				count = 0;
				while(rs.next()) {
					info[count][0] = Integer.valueOf(rs.getInt("id"));
					info[count][1] = rs.getString("name");
					info[count][2] = rs.getString("gongyingshang");
					info[count][3] = rs.getString("cangku");
					count++;
				}
				JTable tabDemo = new JTable(info,title);	
				JTableHeader jth = tabDemo.getTableHeader();
				JScrollPane scpDemo = new JScrollPane();
				scpDemo.getViewport().add(tabDemo);
			}catch(ClassNotFoundException confe) {
				confe.printStackTrace();
				JOptionPane.showMessageDialog(null, "数据源错误","错误",JOptionPane.ERROR_MESSAGE);
			}catch(SQLException sqle) {
				sqle.printStackTrace();
				JOptionPane.showMessageDialog(null, "数据操作错误","错误",JOptionPane.ERROR_MESSAGE);
			}

	}
	public static void main(String[] args) {
		denglu1 de = new denglu1();
	}

}
